
#!/bin/sh
# libpag convertor script

echo "begin"

echo "cd input"
cd ./input

for file in $(ls)
do
  if [ -f $file ];then 
      if [ "${file##*.}"x != "pag"x ];then
         echo $file 
         ../PAGConvertor ${file}
      fi

  else
      echo $file
      if [ ! $1 ]; then
      	../PAGConvertor ${file} 25
      else
        ../PAGConvertor ${file} $1
      fi
  fi
done


echo "end"
