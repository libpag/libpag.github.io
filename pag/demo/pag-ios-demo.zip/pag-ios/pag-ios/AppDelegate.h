//
//  AppDelegate.h
//  pag-ios
//
//  Created by kevingpqi on 2019/2/25.
//  Copyright © 2019年 kevingpqi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

