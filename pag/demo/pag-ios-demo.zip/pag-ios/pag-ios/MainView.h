//
//  MainView.h
//  PAGTestPod
//
//  Created by kevingpqi on 2019/1/15.
//  Copyright © 2019年 kevingpqi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainView : UIView
- (void)loadPAGAndPlay;
@end

