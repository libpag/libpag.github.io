//
//  CombinePAGViewController.h
//  pag-ios
//
//  Created by partyhuang(黄庆然) on 2019/12/30.
//  Copyright © 2019 kevingpqi. All rights reserved.
//

#import "BaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface CombinePAGViewController : BaseViewController

@end

NS_ASSUME_NONNULL_END
