//
//  PixelBufferDemoViewController.h
//  pag-ios
//
//  Created by partyhuang(黄庆然) on 2020/1/8.
//  Copyright © 2020 kevingpqi. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

//渲染目标为pixelbuffer的demo,不上屏
@interface PixelBufferDemoViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
