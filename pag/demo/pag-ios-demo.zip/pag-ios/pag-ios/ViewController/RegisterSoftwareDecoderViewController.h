#import "BaseViewController.h"

/**
 软解注册Demo
 */
@interface RegisterSoftwareDecoderViewController : BaseViewController

@end
