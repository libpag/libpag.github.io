#import "BaseViewController.h"

/**
 图片替换Demo
 */
@interface ReplaceImageViewController : BaseViewController

@end
