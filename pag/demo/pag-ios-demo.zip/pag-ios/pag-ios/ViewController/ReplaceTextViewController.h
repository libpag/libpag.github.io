#import "BaseViewController.h"

/**
 文字替换Demo
 */
@interface ReplaceTextViewController : BaseViewController

@end
