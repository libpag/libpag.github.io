//
//  main.m
//  pag-ios
//
//  Created by kevingpqi on 2019/2/25.
//  Copyright © 2019年 kevingpqi. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
