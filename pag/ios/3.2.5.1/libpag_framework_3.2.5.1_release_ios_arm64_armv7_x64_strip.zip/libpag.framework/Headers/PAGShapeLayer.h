#import <Foundation/Foundation.h>
#import "PAGLayer.h"

@interface PAGShapeLayer : PAGLayer


@end
